var patientsArray = [];

$(document).ready(function () {
  // JQUERY USES 

  //JQUERY USE 1
  $('#toggle').click(function () {
    $('#allData').toggle();
  });
});
//JQUERY USE 2
$("#darkmode").click(function () {
  $('#allData').removeClass('table-light').addClass('table-dark');
});
//JQUERY USE 3
$("#heading").click(function () {
  if ($(this).text() === "Insert a Patient") {
    $(this).text("Fill all the blanks");
  }
  else {
    $(this).text("Insert a Patient");
  }
});


$('#submit').click(function (e) {
  e.preventDefault();

  // SPLIT the value
  const processList = (value) => {
    return value.split(',')
      .map(item => item.trim())
      .filter(item => item.length > 0);
  };

  const newData = {
    PID: $('#id').val().trim(),
    FirstName: $('#fname').val().trim(),
    LastName: $('#lname').val().trim(),
    Email: $('#email').val().trim(),
    NearCity: $('#nearcity').val().trim(),
    Doctor: $('#dname').val().trim(),
    Guardian: $('#gname').val().trim(),
    MedicalConditions: processList($('#mcondition').val()),
    Medications: processList($('#medications').val()),
    Allergies: processList($('#allergies').val()),
    Status: $('#status').val(),
    LastVisitDate: $('#date').val()
  };
  //JQUERY USE 4
  // Basic validation
  if (!newData.PID || !newData.FirstName || !newData.LastName) {
    alert('Please fill in required fields');
    return;
  }
  //JQUERY USE 5
  $.ajax({
    url: 'http://127.0.0.1:3000/api/patients',
    type: 'POST',
    data: JSON.stringify(newData),
    contentType: 'application/json',
    dataType: 'json',
    success: function (response) {
      alert('Record added successfully!');
      patientsArray.push(response);
    },
    error: function (error) {
      alert('Error saving record: ');
    }
  });
});

// GET ALL DATA
$('#viewAllRecords').click(function () {
  $.getJSON('http://127.0.0.1:3000/api/GETpatients', function (data) {
    let output = '';

    if (data.length > 0) {
      output += '<div style="text-align: center;">';
      output += '<table border="1" cellpadding="5" cellspacing="0" style="margin: auto;">';
      output += '<tr><th>Patient ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Near City</th><th>Doctor</th><th>Guardian</th><th>Medical Conditions</th><th>Medications</th><th>Allergies</th><th>Status</th><th>Last Visit Date</th><th>Actions</th></tr>';

      data.forEach(function (record) {
        output += '<tr>';
        output += '<td>' + record.PID + '</td>';
        output += '<td>' + record.FirstName + '</td>';
        output += '<td>' + record.LastName + '</td>';
        output += '<td>' + record.Email + '</td>';
        output += '<td>' + record.NearCity + '</td>';
        output += '<td>' + record.Doctor + '</td>';
        output += '<td>' + record.Guardian + '</td>';
        output += '<td>' + record.MedicalConditions.join(', ') + '</td>';
        output += '<td>' + record.Medications.join(', ') + '</td>';
        output += '<td>' + record.Allergies.join(', ') + '</td>';
        output += '<td>' + record.Status + '</td>';
        output += '<td>' + new Date(record.LastVisitDate).toLocaleDateString() + '</td>';
        output += '<td><button class="btn btn-warning btn-sm edit-btn" data-id="' + record.PID + '">Edit</button> ';
        output += '<button class="btn btn-danger btn-sm delete-btn" data-id="' + record.PID + '">Delete</button></td>';
        output += '</tr>';
      });

      output += '</table>';
    } else {
      output = '<div style="text-align: center;">No patient records found</div><br><br>';
    }

    $('#allData').html(output);


    $('.edit-btn').click(function () {
      const pid = $(this).data('id');
      editPatient(pid);
    });

    $('.delete-btn').click(function () {
      const pid = $(this).data('id');
      if (confirm('Are you sure you want to delete this patient record?')) {
        deletePatient(pid);
      }
    });
  });
});

//SERACH DATA

$('#searchBtn').click(function () {
  const searchType = $('#searchType').val();
  const searchValue = $('#searchValue').val().trim();

  if (!searchValue) {
    alert('Please enter a search term');
    return;
  }

  $.ajax({
    url: 'http://127.0.0.1:3000/api/SEARCHpatients', 
    type: 'POST',
    contentType: 'application/json',
    data: JSON.stringify({ searchType, searchValue }),
    success: function (data) {
      displayResults(data);
    },
    error: function (xhr, status, error) {
      console.error('Error:', error);
      console.log('Response:', xhr.responseText); 
      alert('An error occurred during the search: ' + xhr.responseText);
    }
  });
});

function displayResults(patients) {
  const $resultsBody = $('#resultsBody');
  $resultsBody.empty();

  if (patients.length === 0) {
    $resultsBody.append('<tr><td colspan="7" class="text-center">No patients found</td></tr>');
  } else {
    patients.forEach(patient => {
      $resultsBody.append(`
          <tr>
            <td>${patient.PID}</td>
            <td>${patient.FirstName}</td>
            <td>${patient.LastName}</td>
            <td>${patient.Email}</td>
            <td>${patient.NearCity}</td>
            <td>${patient.Doctor}</td>
            <td>${patient.Guardian}</td>
          </tr>
        `);
    });
  }

  $('#searchResults').show();
}




// UPDATE DATA
function editPatient(pid) {
  $.getJSON(`http://127.0.0.1:3000/api/GETpatients/${pid}`, function (patient) {

    $('#editId').val(patient.PID);
    $('#editFname').val(patient.FirstName);
    $('#editLname').val(patient.LastName);
    $('#editEmail').val(patient.Email);
    $('#editNearcity').val(patient.NearCity);
    $('#editDname').val(patient.Doctor);
    $('#editGname').val(patient.Guardian);
    $('#editMcondition').val(patient.MedicalConditions.join(', '));
    $('#editMedications').val(patient.Medications.join(', '));
    $('#editAllergies').val(patient.Allergies.join(', '));
    $('#editStatus').val(patient.Status);


    const visitDate = new Date(patient.LastVisitDate);
    const formattedDate = visitDate.toISOString().split('T')[0];
    $('#editDate').val(formattedDate);


    const editModal = new bootstrap.Modal(document.getElementById('editModal'));
    editModal.show();
  }).fail(function () {
    alert('Error loading patient data');
  });
}


$('#saveChanges').click(function () {
  const processList = (value) => {
    return value.split(',')
      .map(item => item.trim())
      .filter(item => item.length > 0);
  };

  const updatedData = {
    PID: $('#editId').val(),
    FirstName: $('#editFname').val().trim(),
    LastName: $('#editLname').val().trim(),
    Email: $('#editEmail').val().trim(),
    NearCity: $('#editNearcity').val().trim(),
    Doctor: $('#editDname').val().trim(),
    Guardian: $('#editGname').val().trim(),
    MedicalConditions: processList($('#editMcondition').val()),
    Medications: processList($('#editMedications').val()),
    Allergies: processList($('#editAllergies').val()),
    Status: $('#editStatus').val(),
    LastVisitDate: $('#editDate').val()
  };

  $.ajax({
    url: `http://127.0.0.1:3000/api/patients/${updatedData.PID}`,
    type: 'PUT',
    data: JSON.stringify(updatedData),
    contentType: 'application/json',
    dataType: 'json',
    success: function (response) {
      alert('Record updated successfully!');
      $('#editModal').modal('hide');
      $('#viewAllRecords').click();
    },
    error: function (xhr, status, error) {
      console.error('Error:', error);
      alert('Error updating record: ' + (xhr.responseJSON?.message || 'Unknown error'));
    }
  });
});


// DELETE DATA
function deletePatient(pid) {
  $.ajax({
    url: `http://127.0.0.1:3000/api/patients/${pid}`,
    type: 'DELETE',
    success: function (response) {
      alert('Record deleted successfully!');
      $('#viewAllRecords').click();
    },
    error: function (xhr, status, error) {
      console.error('Error:', error);
      alert('Error deleting record: ' + (xhr.responseJSON?.message || 'Unknown error'));
    }
  });
}









































