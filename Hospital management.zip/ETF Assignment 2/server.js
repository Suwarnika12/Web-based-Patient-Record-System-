const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// CONNECT TO MONGO DB
mongoose.connect('mongodb://localhost:27017/etf',
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log("Connected to MongoDB database: ETF Assignment 2"))
  .catch(err => console.error("Failed to connect to MongoDB", err));


const PatientSchema = new mongoose.Schema({
  PID: String,
  FirstName: String,
  LastName: String,
  Email: String,
  NearCity: String,
  Doctor: String,
  Guardian: String,
  MedicalConditions: [String],
  Medications: [String],
  Allergies: [String],
  Status: String,
  LastVisitDate: Date
});

const Patient = mongoose.model('Patient', PatientSchema); //under etf database in mongodb, we create Pateint collection to store records.

// INSERT ALL DATA
app.post('/api/patients', async (req, res) => {
  try {
    const patient = await Patient.create(req.body);// Create new patients in MongoDB
    res.status(201).json({
      message: 'Patient Created Successfully',
      patient: patient
    });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get all patients
app.get('/api/GETpatients', async (req, res) => {
  try {
    const patients = await Patient.find();
    res.json(patients);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

//SEARCH DATA
app.post('/api/SEARCHpatients', async (req, res) => {
  try {
    const { searchType, searchValue } = req.body;
    
    let query = {};
    
    switch(searchType) {
      case 'S-PID':
        query.PID = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-Fname':
        query.FirstName = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-Lname':
        query.LastName = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-Email':
        query.Email = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-NearCity':
        query.NearCity = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-Doctor':
        query.Doctor = { $regex: searchValue, $options: 'i' };
        break;
      case 'S-Guardian':
        query.Guardian = { $regex: searchValue, $options: 'i' };
        break;
      default:
        // If no valid search type, return all patients
        query = {};
    }
    
    const results = await Patient.find(query);
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


//get the patients using PID only to fill the update pop up box
app.get('/api/GETpatients/:pid', async (req, res) => {
    try {
        const patient = await Patient.findOne({ PID: req.params.pid });
        if (!patient) {
            return res.status(404).json({ message: 'Patient not found' });
        }
        res.json(patient);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update patient
app.put('/api/patients/:pid', async (req, res) => {
  try {
    const patient = await Patient.findOneAndUpdate(
      { PID: req.params.pid },
      req.body,
      { new: true }
    );

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    res.json({
      message: 'Patient updated successfully',
      patient: patient
    });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete patient
app.delete('/api/patients/:pid', async (req, res) => {
  try {
    const patient = await Patient.findOneAndDelete({ PID: req.params.pid });

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    res.json({ message: 'Patient deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});